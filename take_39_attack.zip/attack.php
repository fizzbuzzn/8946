<?php

  echo 'h@cked!!!';

?>